/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.espol.edu.tdas;

/**
 *
 * @author CltControl
 */
public class ArrayList<E> implements List<E> {
    
    private E[] array;
    private int capacity = 10;
    private int efectivo = 0;
    
    public ArrayList(){
        array = (E []) new Object[capacity];
        efectivo = 0;
    }

    @Override
    public boolean isEmpty() {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        return efectivo == 0;
    }

    @Override
    public int size() {
        //To change body of generated methods, choose Tools | Templates.
        return efectivo;
    }

    @Override
    public boolean addFirst(E element) {
         //To change body of generated methods, choose Tools | Templates.
         if(element == null) 
             return false;
         else if(efectivo == capacity)
             addCapacity();
         desplazar();
         array[0]=element;
         efectivo++;
         return true;
    }
    
    private void desplazar(){
        for(int i = efectivo-1; i>=0;i--)
            array[i+1]=array[i];
    }

    @Override
    public boolean addLast(E element) {
         //To change body of generated methods, choose Tools | Templates.
         if(element == null) 
             return false;
         else if(efectivo == capacity)
             addCapacity();
         array[efectivo++]=element;
         return true;
    }
    
    private void addCapacity(){
        E[] tmp = (E[]) new Object[(efectivo/2)+efectivo];
        for(int i = 0; i<efectivo;i++)
            tmp[i] = array[i];
        array = tmp;
        capacity = efectivo + (efectivo/2);
    }

    @Override
    public boolean removeFirst() {
         //To change body of generated methods, choose Tools | Templates.
         if(isEmpty()) return false;
         move();
         array[efectivo-1]=null;
         efectivo--;
         return true;
    }
    
    private void move(){
        for(int i = efectivo -1 ;i>0;i--){
            array[i-1]=array[i];
        }
    }

    @Override
    public boolean removeLast() {
         //To change body of generated methods, choose Tools | Templates.
         if(isEmpty()) return false;
         array[efectivo-1]=null;
         efectivo--;
         return true;
    }

    @Override
    public boolean removeElement(E element) {
        //To change body of generated methods, choose Tools | Templates.
        return true;
    }

    @Override
    public boolean set(E element, int index) {
         //To change body of generated methods, choose Tools | Templates.
         return true;
    }
//    
    
}
