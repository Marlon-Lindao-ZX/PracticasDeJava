/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.espol.edu.tdas;

/**
 *
 * @author CltControl
 */
public interface List<E> {
    
    boolean isEmpty();
    int size();
    boolean addFirst(E element);
    boolean addLast(E element);
    boolean removeFirst();
    boolean removeLast();
    boolean removeElement(E element);
    boolean set(E element, int index);
}
